#!/bin/bash

# 这里可以放入代码运行命令
echo "program start..."
python3 run.py