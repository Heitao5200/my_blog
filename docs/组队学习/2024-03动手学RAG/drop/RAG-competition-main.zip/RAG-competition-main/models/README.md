# 模型都放在此目录下即可

1、Qwen-7B-Chat

使用官方线上模型，下载地址略；

2、gte-large-zh

下载地址：[thenlper/gte-large-zh · Hugging Face](https://huggingface.co/thenlper/gte-large-zh)

3、bge-large-zh

下载地址：[BAAI/bge-large-zh · Hugging Face](https://huggingface.co/BAAI/bge-large-zh)

4、bge-reranker-large

下载地址：[BAAI/bge-reranker-large · Hugging Face](https://huggingface.co/BAAI/bge-reranker-large)